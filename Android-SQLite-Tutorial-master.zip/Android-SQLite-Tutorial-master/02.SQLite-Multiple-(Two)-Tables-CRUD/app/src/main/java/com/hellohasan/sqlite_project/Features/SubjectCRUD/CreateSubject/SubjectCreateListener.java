package com.hellohasan.sqlite_project.Features.SubjectCRUD.CreateSubject;

public interface SubjectCreateListener {
    void onSubjectCreated(Subject subject);
}
