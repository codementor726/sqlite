package com.hellohasan.sqlite_project.Features.StudentCRUD.CreateStudent;

public interface StudentCreateListener {
    void onStudentCreated(Student student);
}
