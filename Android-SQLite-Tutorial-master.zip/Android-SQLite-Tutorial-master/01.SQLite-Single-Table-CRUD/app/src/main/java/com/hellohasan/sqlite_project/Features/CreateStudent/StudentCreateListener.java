package com.hellohasan.sqlite_project.Features.CreateStudent;

public interface StudentCreateListener {
    void onStudentCreated(Student student);
}
